/*
  MPU9250.h
  Sylvain Garnavault
  garnav@wanadoo.fr

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in the Software without restriction,
  including without limitation the rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef MPU9250_h
#define MPU9250_h

#include "Arduino.h"
#include "SPI.h"     // SPI library

// MPU9250 registers

#define TEMP_OUT      	  0x41
#define ACCEL_CONFIG      0x1C
#define ACCEL_CONFIG2     0x1D
#define ACCEL_OFFSETS	  0x77
#define ACCEL_OUT         0x3B
#define GYRO_CONFIG       0x1B
#define GYRO_OFFSETS	  0x13
#define GYRO_OUT      	  0x43
#define CONFIG            0x1A
#define SMPDIV            0x19
#define PWR_MGMNT_1       0x6B
#define PWR_CYCLE         0x20
#define PWR_RESET         0x80
#define CLOCK_SEL_PLL     0x01
#define PWR_MGMNT_2       0x6C
#define SEN_ENABLE        0x00
#define DIS_GYRO          0x07
#define USER_CTRL         0x6A
#define I2C_MST_EN        0x20
#define I2C_MST_CLK       0x0D
#define I2C_MST_CTRL      0x24
#define I2C_SLV0_ADDR     0x25
#define I2C_SLV0_REG      0x26
#define I2C_SLV0_DO       0x63
#define I2C_SLV0_CTRL     0x27
#define I2C_SLV0_EN       0x80
#define I2C_READ_FLAG     0x80
#define EXT_SENS_DATA_00  0x49
#define WHO_AM_I          0x75

// AK8963 registers
#define AK8963_I2C_ADDR   0x0C
#define AK8963_HXL        0x03
#define AK8963_CNTL1      0x0A
#define AK8963_PWR_DOWN   0x00
#define AK8963_CNT_MEAS1  0x12
#define AK8963_CNT_MEAS2  0x16
#define AK8963_FUSE_ROM   0x0F
#define AK8963_CNTL2      0x0B
#define AK8963_RESET      0x01
#define AK8963_ASA        0x10
#define AK8963_WHO_AM_I   0x00

// SPI VALUES
#define SPI_READ      	  0x80
#define SPI_LS_CLOCK      1000000    // 1 MHz
#define SPI_HS_CLOCK      15000000   // 15 MHz

// TEMP SCALES
#define TEMP_SCALE 		  333.87f
#define TEMP_OFFSET 	  21.f

// constants
#define GRAVITY 		  9.80665f
#define D2R 			  0.01745329251f
	
enum GyroRange
{
  GYRO_RANGE_250DPS,
  GYRO_RANGE_500DPS,
  GYRO_RANGE_1000DPS,
  GYRO_RANGE_2000DPS
};
enum AccelRange
{
  ACCEL_RANGE_2G,
  ACCEL_RANGE_4G,
  ACCEL_RANGE_8G,
  ACCEL_RANGE_16G
};
enum AccelDlpfBandwidth
{
  ACCEL_DLPF_BANDWIDTH_218HZ = 0x01,	// delay 01.88 ms
  ACCEL_DLPF_BANDWIDTH_99HZ  = 0x02,	// delay 02.88 ms
  ACCEL_DLPF_BANDWIDTH_45HZ  = 0x03,	// delay 04.88 ms
  ACCEL_DLPF_BANDWIDTH_21HZ  = 0x04,	// delay 08.87 ms
  ACCEL_DLPF_BANDWIDTH_10HZ  = 0x05,	// delay 16.83 ms
  ACCEL_DLPF_BANDWIDTH_5HZ   = 0x06,  	// delay 32.48 ms
  ACCEL_DLPF_BANDWIDTH_420HZ = 0x07		// delay 01.38 ms
};

enum GyroDlpfBandwidth
{
  GYRO_DLPF_BANDWIDTH_250HZ,	 		// delay 00.97 ms
  GYRO_DLPF_BANDWIDTH_184HZ,	 		// delay 02.90 ms
  GYRO_DLPF_BANDWIDTH_92HZ,	 			// delay 03.90 ms
  GYRO_DLPF_BANDWIDTH_41HZ,	 			// delay 05.90 ms
  GYRO_DLPF_BANDWIDTH_20HZ,	 			// delay 09.90 ms	
  GYRO_DLPF_BANDWIDTH_10HZ,   			// delay 17.85 ms
  GYRO_DLPF_BANDWIDTH_5HZ,    			// delay 33.48 ms
  GYRO_DLPF_BANDWIDTH_3600HZ  			// delay 00.17 ms
};

class MPU9250 {
  public:
    MPU9250(SPIClass &bus, uint8_t csPin);
    void begin();

    void setAccelRange(byte range);
    void setAccelRange(AccelRange range);
    void setGyroRange(byte range);
    void setGyroRange(GyroRange range);
    void setAccelDlpfBandwidth(byte bandwidth);
    void setAccelDlpfBandwidth(AccelDlpfBandwidth bandwidth);
    void setGyroDlpfBandwidth(byte bandwidth);
    void setGyroDlpfBandwidth(GyroDlpfBandwidth bandwidth);
    void setSampleRateDivider(uint8_t samplerate);

    void  readSensor();
    
	float getAccelX_mss();
    float getAccelY_mss();
    float getAccelZ_mss();
    float getAccelN_mss();
	
    float getGyroX_rads();
    float getGyroY_rads();
    float getGyroZ_rads();
    float getGyroN_rads();
    
	float getMagX_uT();
    float getMagY_uT();
    float getMagZ_uT();
    float getMagN_uT();
    
	float getTemperature_C();

    void  calibrateGyro();
    float getGyroBiasX_rads();
    float getGyroBiasY_rads();
    float getGyroBiasZ_rads();
    void  setGyroBiasX_rads(float bias);
    void  setGyroBiasY_rads(float bias);
    void  setGyroBiasZ_rads(float bias);

    void  calibrateAccel();
    float getAccelBiasX_mss();
    float getAccelScaleFactorX();
    float getAccelBiasY_mss();
    float getAccelScaleFactorY();
    float getAccelBiasZ_mss();
    float getAccelScaleFactorZ();
    void  setAccelCalX(float bias, float scaleFactor);
    void  setAccelCalY(float bias, float scaleFactor);
    void  setAccelCalZ(float bias, float scaleFactor);

    void  calibrateMag();
    float getMagBiasX_uT();
    float getMagScaleFactorX();
    float getMagBiasY_uT();
    float getMagScaleFactorY();
    float getMagBiasZ_uT();
    float getMagScaleFactorZ();
    void  setMagCalX(float bias, float scaleFactor);
    void  setMagCalY(float bias, float scaleFactor);
    void  setMagCalZ(float bias, float scaleFactor);

  private:
    // SPI
    SPIClass *_spi;
    uint8_t _csPin;
    bool _useSPIHS;

    // buffer for reading from sensor
    uint8_t _buffer[21];

	// config
	AccelRange         _accelRange;
	AccelDlpfBandwidth _accelBandwidth;
	GyroRange  	  	   _gyroRange;
	GyroDlpfBandwidth  _gyroBandwidth;
	byte          	   _samplerateDivider;
	
    // data buffer
    float _ax, _ay, _az, _an;
    float _gx, _gy, _gz, _gn;
    float _hx, _hy, _hz, _hn;
    float _t;

    // scale factors
    float _accelScale;
    float _gyroScale;
    float _magScaleX, _magScaleY, _magScaleZ;

    // gyro bias estimation
    float _gxb, _gyb, _gzb;

    // accel bias and scale factor estimation
    float _axb, _ayb, _azb;
    float _axs = 1.0f;
    float _ays = 1.0f;
    float _azs = 1.0f;

    // magnetometer bias and scale factor estimation
    float _hxmin, _hymin, _hzmin;
    float _hxb, _hyb, _hzb;
    float _hxs = 1.0f;
    float _hys = 1.0f;
    float _hzs = 1.0f;

    // transformation matrix
    // transform the accel and gyro axes to match the magnetometer axes
    const int16_t tX[3] = {0,  1,  0};
    const int16_t tY[3] = {1,  0,  0};
    const int16_t tZ[3] = {0,  0, -1};

    // private functions
    int whoAmI();
    int whoAmIAK8963();    
	void writeRegister(uint8_t subAddress, uint8_t data);
    void readRegisters(uint8_t subAddress, uint8_t count, uint8_t* dest);
    void writeAK8963Register(uint8_t subAddress, uint8_t data);
    void readAK8963Registers(uint8_t subAddress, uint8_t count, uint8_t* dest);
};
#endif