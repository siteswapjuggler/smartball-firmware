var translation = {'fr': new Array(), 'en': new Array()};

translation['fr'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - configuration',
	
	//WELCOMING TEXT
	'welcome-title': 'Bienvenue',
	'welcome-text': 'Ce formulaire permet de configurer la connexion WiFi de votre balle.',
	
	//WIFI FORM
	'wifi-form-title': 'Configuration WiFi',
	'wifi-form-network-label': 'Réseaux disponibles',
	'wifi-form-network-nowifi': 'aucun réseau disponible',
	'wifi-form-network-selector': 'séléctionnez un réseau',
	'wifi-form-password-label': 'Mot de passe',
	'wifi-form-password-placehoder': 'mot de passe',
	'submit-button': 'Appliquer',
	
	//CURRENT PARAMETERS
	'parameters-title': 'Paramètres actuels',
	'test-button': 'Test'
	};
	
translation['en'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - configuration',
	
	//WELCOMING TEXT
	'welcome-title': 'Welcome',
	'welcome-text': 'This form allow you to configure your ball WiFi connection.',
	
	//WIFI FORM
	'wifi-form-title': 'WiFi configuration',
	'wifi-form-network-label': 'Available networks',
	'wifi-form-network-nowifi': 'no network available',
	'wifi-form-network-selector': 'select your network',
	'wifi-form-password-label': 'Password',
	'wifi-form-password-placehoder': 'password',
	'submit-button': 'Apply',
	
	//CURRENT PARAMETERS
	'parameters-title': 'Current parameters',
	'test-button': 'Test'
	};
function changeLanguage(lang) {
	var i, label, allElements = document.getElementsByTagName('*');

	document.title = translation[lang]['title'];
	document.getElementsByTagName('html')[0].lang = lang;

	for (i = 0; i < allElements.length; i++) {
    if (allElements[i].hasAttribute('multi')) {
			label = allElements[i].getAttribute('multi');
			if (allElements[i].hasAttribute('placeholder')) 
				allElements[i].setAttribute('placeholder',translation[lang][label]);
			else
				allElements[i].innerHTML = translation[lang][label];
    }
  }
}

var lang = window.navigator.userLanguage || window.navigator.language;
var l = lang.split("-");
lang = l[0];
if (!(lang in translation)) lang = 'en';

changeLanguage(lang);
function togglePassword() {
	pwd = document.getElementById("pwd");
	view = document.getElementById("view");
	
	if (pwd.getAttribute("type") == "password") {
		pwd.setAttribute("type","text");
		view.classList.remove("icon-eye-closed");
		view.classList.add("icon-eye");
	}
	else {
		pwd.setAttribute("type","password");
		view.classList.remove("icon-eye");
		view.classList.add("icon-eye-closed");
	}
}

function testBall() {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "./testBall", true);
	xhttp.send();
}

function getParameters() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200) {
			parameters = this.response.split(",");
			document.getElementById("NT").innerHTML = parameters[0];
			document.getElementById("ID").innerHTML = parameters[1];
			document.getElementById("SN").innerHTML = parameters[2];
			document.getElementById("FW").innerHTML = parameters[3];
			document.getElementById("EP").innerHTML = parameters[4];
			document.getElementById("PR").innerHTML = parameters[5];
    }
  };
  xhttp.open("GET", "./getParameters", true);
  xhttp.send();
}

function getNetworks(refresh) {
  var i, html, options, xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (this.response === "false") {
				html += "<option disabled selected>"+translation[lang]['wifi-form-network-nowifi']+"</option>";
			}
			else {
				html += "<option disabled selected>"+translation[lang]['wifi-form-network-selector']+"</option>";
				options = this.response.split(",");
				for (i=0; i < options.length; i++) {
					html += "<option>"+options[i]+"</option>";
				}
			}
			document.getElementById("ssid").innerHTML = html;
		}
  };
  xhttp.open("GET", refresh ? "./refreshNetworks" : "./getNetworks", true);
  xhttp.send();
}

getNetworks(false);
getParameters();