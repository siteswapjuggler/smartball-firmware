var translation = {'fr': new Array(), 'en': new Array()};

translation['fr'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - redémarrage',
	
	//MAIN TEXT
	'main-title': 'Sauvegarde en cours',
	'main-text':  'Merci beaucoup, votre balle va maintenant redémarrer et tenter de se connecter à son nouveau réseau.',
	};
	
translation['en'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - rebooting',
	
	//MAIN TEXT
	'main-title': 'Saving in progress',
	'main-text':  'Thanks a lot, your ball will now reboot and try to connect to it\'s new network.'
	};
function changeLanguage(lang) {
	var i, label, allElements = document.getElementsByTagName('*');

	document.title = translation[lang]['title'];
	document.getElementsByTagName('html')[0].lang = lang;

	for (i = 0; i < allElements.length; i++) {
    if (allElements[i].hasAttribute('multi')) {
			label = allElements[i].getAttribute('multi');
			if (allElements[i].hasAttribute('placeholder')) 
				allElements[i].setAttribute('placeholder',translation[lang][label]);
			else
				allElements[i].innerHTML = translation[lang][label];
    }
  }
}

var lang = window.navigator.userLanguage || window.navigator.language;
var l = lang.split("-");
lang = l[0];
if (!(lang in translation)) lang = 'en';

changeLanguage(lang);
function rebootBall() {
	document.addEventListener("DOMContentLoaded", function(event) { 
			var xhttp = new XMLHttpRequest();
			xhttp.open("GET", "./rebootBall", true);
			xhttp.send();
		});
}

rebootBall();