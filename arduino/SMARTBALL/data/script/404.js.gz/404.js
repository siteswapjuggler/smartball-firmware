var translation = {'fr': new Array(), 'en': new Array()};

translation['fr'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - erreur 404',
	
	//MAIN TEXT
	'main-title': 'Erreur 404',
	'main-text':  'La ressource que vous recherchez n\'est pas disponible sur ce serveur.',
	};
	
translation['en'] = {
	//TITLE AND METADATA
	'title':	'SMARTBALL - 404 error',
	
	//MAIN TEXT
	'main-title': '404 error',
	'main-text':  'The ressource you\'re looking for is not available on this server.'
	};
function changeLanguage(lang) {
	var i, label, allElements = document.getElementsByTagName('*');

	document.title = translation[lang]['title'];
	document.getElementsByTagName('html')[0].lang = lang;

	for (i = 0; i < allElements.length; i++) {
    if (allElements[i].hasAttribute('multi')) {
			label = allElements[i].getAttribute('multi');
			if (allElements[i].hasAttribute('placeholder')) 
				allElements[i].setAttribute('placeholder',translation[lang][label]);
			else
				allElements[i].innerHTML = translation[lang][label];
    }
  }
}

var lang = window.navigator.userLanguage || window.navigator.language;
var l = lang.split("-");
lang = l[0];
if (!(lang in translation)) lang = 'en';

changeLanguage(lang);